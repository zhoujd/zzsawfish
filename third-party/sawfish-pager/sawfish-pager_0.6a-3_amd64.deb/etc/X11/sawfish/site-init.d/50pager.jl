;
; Start the pager
;
(require 'pager)
(setq pager-executable "/usr/lib/sawfish-pager/pager")
(add-hook 'after-initialization-hook pager t)
